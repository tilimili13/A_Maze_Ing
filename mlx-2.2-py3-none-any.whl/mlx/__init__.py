# src/mlx/__init__.py
from .mlx import *
